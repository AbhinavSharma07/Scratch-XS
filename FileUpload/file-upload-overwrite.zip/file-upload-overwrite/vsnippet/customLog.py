## [Used to custom "log"]
# Replace & hack me if you can!
##
def log():
    print("[LOG] Some random log here")
